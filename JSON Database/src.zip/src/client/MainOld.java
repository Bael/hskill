package client;

import com.beust.jcommander.JCommander;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;
import java.util.function.BiConsumer;

public class MainOld {
    private final static Gson gson = new GsonBuilder().setPrettyPrinting().create();

    //    public static void main(String[] args) throws IOException {
//        SetCommand setCommand = new SetCommand("key", "dfdf");
//        System.out.println(setCommand.getCommand());
//
//    }
//    public static void main(String[] args) throws IOException {
//        Args parseArgs = new Args();
//        JCommander.newBuilder()
//                .addObject(parseArgs)
//                .build()
//                .parse(args);
//        Command command = readCommand(parseArgs);
//        String address = "127.0.0.1";
//        int port = 23456;
//        ClientDBConnection.connect(address, port, ClientDBConnection.exchange(command.getCommand()));
//    }

    private static Command readCommand(Args parseArgs) throws IOException {
        if (Objects.nonNull(parseArgs.getFilename())) {
            Path path = Paths.get("src/client/data/", parseArgs.getFilename());
            String commandStr = Files.readString(path);
            RawCommand command = gson.fromJson(commandStr, RawCommand.class);
            return Command.parse(command.type, command.key, command.value);
        } else {
            return Command.parse(parseArgs.getType(), parseArgs.getKey(), parseArgs.getValue());
        }
    }

    private enum CommandType {
        set, get, delete, exit
    }

    private static class RawCommand {
        String type;
        String key;
        String value;

        public RawCommand(String type, String key, String value) {
            this.type = type;
            this.key = key;
            this.value = value;
        }
    }
    interface Command {
        static Command parse(String type, String key, String message) {
            switch (type) {
                case "get":
                    return new GetCommand(key);
                case "set":
                    return new SetCommand(key, message);
                case "delete":
                    return new DeleteCommand(key);
                case "exit":
                    return new ExitCommand();
                default:
                    throw new RuntimeException("Not supported command!" + type);
            }
        }

        default String getCommand() {
            return gson.toJson(this);
        }

        Command fromJson(String json);
    }

    private static class GetCommand implements Command {
        String type = "get";
        String key;
        public GetCommand(String key) {
            this.key = key;
        }

        @Override
        public Command fromJson(String json) {
            return gson.fromJson(json, GetCommand.class);
        }
    }

    private static class SetCommand implements Command {
        String type = "set";
        String key;
        String value;
        public SetCommand(String key, String value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public Command fromJson(String json) {
            return gson.fromJson(json, SetCommand.class);
        }
    }

    private static class DeleteCommand implements Command {
        String type = "delete";
        String key;
        public DeleteCommand(String key) {
            this.key = key;
        }

        @Override
        public Command fromJson(String json) {
            return gson.fromJson(json, DeleteCommand.class);
        }
    }

    private static class ExitCommand implements Command {
        String type = "exit";
//        @Override
//        public String getCommand() {
//            return "exit";
//        }

        @Override
        public Command fromJson(String json) {
            return gson.fromJson(json, ExitCommand.class);
        }
    }
    public static class ClientDBConnection {
        public static void connect(String address, int port, BiConsumer<DataInputStream, DataOutputStream> consumer) throws IOException {
            System.out.println("Client started!");
            try (Socket socket = new Socket(InetAddress.getByName(address), port);
                 DataInputStream input = new DataInputStream(socket.getInputStream());
                 DataOutputStream output = new DataOutputStream(socket.getOutputStream());) {
                consumer.accept(input, output);
            }
        }

        public static BiConsumer<DataInputStream, DataOutputStream> exchange(String command) throws IOException {
            return (dataInputStream1, dataOutputStream1) -> {
                try {
                    System.out.println("Sent: " + command);
                    dataOutputStream1.writeUTF(command);
                    String response = dataInputStream1.readUTF();
                    System.out.println("Received: " + response);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            };
        }
    }
}