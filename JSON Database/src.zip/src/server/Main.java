package server;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

import java.io.*;
import java.lang.reflect.Type;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.file.*;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import static server.Main.ActionType.*;

public class Main {
    private static final Gson gson = new Gson();
    public static void main(String[] args) throws IOException {
        String address = "127.0.0.1";
        int port = 23456;

        JsonDBServer server = JsonDBServer.createServer(address, port);
        server.accept();
        //System.out.println(Paths.get("./").toAbsolutePath());

    }

//    private static Command getCommand(BufferedReader reader) throws IOException {
//        String raw = reader.readLine();
//        return getCommand(raw);
//    }

    private static Command getCommand(String raw) throws IOException {
        Command command;
        Map<String, String> map = gson.fromJson(raw, Map.class);

        ActionType type = ActionType.valueOf(map.get("type").toUpperCase());
        String key = map.get("key");
        switch (type) {
            case EXIT:
                return new Command(EXIT);
            case GET:
                return new Command(GET, key);
            case DELETE:
                return new Command(DELETE, key);
            case SET:
                return new Command(SET, key, map.get("value"));
            default:
                throw new RuntimeException("Wrong command!");
        }
    }

    enum ActionType {
        GET, DELETE, SET, EXIT
    }

    public static class JsonDBServer {
        private final int port;
        private final String address;
        private final Engine engine;
        private final ExecutorService executorService;
        private boolean isStopped = false;
        private ServerSocket serverSocket;

        public JsonDBServer(String address, int port) {
            this.address = address;
            this.port = port;
            engine = new Engine();
            executorService = Executors.newFixedThreadPool(10);
        }

        public static JsonDBServer createServer(String address, int port) throws IOException {
            return new JsonDBServer(address, port);
        }

        public void acceptInThread(ServerSocket server, Socket socket) throws IOException {
            try (DataInputStream input = new DataInputStream(socket.getInputStream());
                 DataOutputStream output = new DataOutputStream(socket.getOutputStream())) {
                String commandString = input.readUTF(); // reading a message
                Command command = getCommand(commandString);
                System.out.println("Received: " + commandString);
                Response response = engine.execute(command);
                System.out.println("Sent:" + response.getResponse());
                output.writeUTF(response.getResponse()); // resend it to the client
                if (command.type == EXIT) {
                    stop();
                }
            } catch (IOException e) {
//                server.close();
                throw new RuntimeException(e);
            }
        }

        private synchronized boolean isStopped() {
            return this.isStopped;
        }

        public synchronized void stop() {
            this.isStopped = true;
            try {
                this.serverSocket.close();
                executorService.shutdown();
            } catch (IOException e) {
                throw new RuntimeException("Error closing server", e);
            }
        }
        private void openServerSocket() {
            try {
                this.serverSocket = new ServerSocket(port, 50, InetAddress.getByName(address));
            } catch (IOException e) {
                throw new RuntimeException("Cannot open port 8080", e);
            }
        }
        public void accept() throws IOException {
            openServerSocket();
            System.out.println("Server started!");
            while (!isStopped()) {
                try {
                    Socket socket = serverSocket.accept(); // accepting a new client
                    executorService.execute(() -> {
                        try {
                            acceptInThread(serverSocket, socket);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    });

                } catch (Exception runtimeException) {
                    if (isStopped()) {
                        System.out.println("Server Stopped.");
                        System.out.println(runtimeException.getMessage());

                        return;
                    }
//                    throw new RuntimeException("Error accepting client connection", runtimeException);
                }
            }

        }
    }

    enum ResponseStatus {
        OK, ERROR
    }

    private static class Response {
        ResponseStatus status;
        String value;

        String getResponse() {
            if (status == ResponseStatus.ERROR) {
                return gson.toJson(Map.of("response", status.name(), "reason", value));
            } else {
                if (value != null) {
                    return gson.toJson(Map.of("response", status.name(), "value", value));
                } else {
                    return gson.toJson(Map.of("response", status.name()));
                }
            }
        }

        public Response(ResponseStatus status, String value) {
            this.status = status;
            this.value = value;
        }

        private static Response of(ResponseStatus status, String value) {
            return new Response(status, value);
        }

        private static final Response noSuchKeyResponse = Response.of(ResponseStatus.ERROR, "No such key");

        private static Response noSuchKeyResponse() {
            return noSuchKeyResponse;
        }

        private static Response of(ResponseStatus status) {
            return new Response(status, null);
        }
    }


    private interface Memory {
        void put(String key, String value);

        String get(String key);

        boolean delete(String key);

        boolean contains(String key);
    }

    private static class ConcurrentHandlerDecorator implements Memory {
        private final ReadWriteLock lock = new ReentrantReadWriteLock();
        private final Memory memory;

        private ConcurrentHandlerDecorator(Memory memory) {
            this.memory = memory;
        }

        @Override
        public void put(String key, String value) {
            Lock writeLock = lock.writeLock();
            writeLock.lock();
            memory.put(key, value);
            writeLock.unlock();
        }

        @Override
        public String get(String key) {
            Lock readLock = lock.readLock();
            readLock.lock();
            String value = memory.get(key);
            readLock.unlock();
            return value;
        }

        @Override
        public boolean delete(String key) {
            Lock writeLock = lock.writeLock();
            writeLock.lock();
            boolean value = memory.delete(key);
            writeLock.unlock();
            return value;
        }

        @Override
        public boolean contains(String key) {
            Lock readLock = lock.readLock();
            readLock.lock();
            boolean value = memory.contains(key);
            readLock.unlock();
            return value;
        }
    }

    private static class FileMemory implements Memory {
        Path path = Paths.get("src/server/data/db.json");
//            String FILENAME_LOCAL_ENVIRONMENT = System.getProperty("user.dir") + "/JSON Database/task/src/server/data/db.json";
//            Path path = Paths.get(FILENAME_LOCAL_ENVIRONMENT);

        private static final Type KEY_VALUE_TYPE = new TypeToken<Map<String, String>>() {
        }.getType();

        private static void log(String str) {
//            try {
////                Files.writeString(Paths.get("/home/dk/learn/java/log.txt"), str, StandardOpenOption.APPEND);
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }

        }

        @Override
        public void put(String key, String value) {
            log("put " + key + " -> " + value);
            Map<String, String> data = readMemory();
            data.put(key, value);
            writeMemory(data);
        }

        private void writeMemory(Map<String, String> data) {
            String result = gson.toJson(data);
            try {
                Files.writeString(path, result);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        private Map<String, String> readMemory() {
            Map<String, String> data;
            try (JsonReader reader = new JsonReader(new FileReader(path.toFile()))) {
                data = gson.fromJson(reader, KEY_VALUE_TYPE);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return data;
        }

        @Override
        public String get(String key) {
            log("get " + key);
            Map<String, String> data = readMemory();
            return data.get(key);
        }

        @Override
        public boolean delete(String key) {
            log("delete " + key);
            Map<String, String> data = readMemory();
            if (data.containsKey(key)) {
                data.remove(key);
                writeMemory(data);
                return true;
            }
            return false;
        }

        @Override
        public boolean contains(String key) {
            Map<String, String> data = readMemory();
            return data.containsKey(key);
        }
    }

    private static class Engine {
        private final Memory memory = new ConcurrentHandlerDecorator(new FileMemory());

        public Response set(String key, String value) {
            memory.put(key, value);
            return Response.of(ResponseStatus.OK);
        }

        public Response get(String key) {
            if (!memory.contains(key)) {
                return Response.noSuchKeyResponse();
            }
            return Response.of(ResponseStatus.OK, memory.get(key));
        }

        public Response execute(Command command) {
            switch (command.type) {
                case SET:
                    return set(command.key, command.value);
                case GET:
                    return get(command.key);
                case DELETE:
                    return delete(command.key);
                case EXIT:
                    return Response.of(ResponseStatus.OK);
            }
            throw new RuntimeException("Unsupported command! " + command);

        }

        private Response delete(String key) {
            if (!memory.delete(key)) {
                return Response.noSuchKeyResponse();
            }
            return Response.of(ResponseStatus.OK);
        }
    }

    private static class Command {
        String value;
        ActionType type;
        String key;

        public Command(ActionType type, String key) {
            this.type = type;
            this.key = key;
        }

        public Command(ActionType type) {
            this.type = type;
        }

        public Command(ActionType type, String key, String value) {
            this.type = type;
            this.key = key;
            this.value = value;
        }
    }
}
